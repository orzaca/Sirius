/* REALIZA LA FUNCION DEL MODAL SALDOS*/

function openTipi() {
    document.getElementById('myModal').style.display = "block";
}

function closeTipi() {
    document.getElementById('myModal').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModal')) {
        closeTipi();
    }
}

function openGuion() {
    document.getElementById('ModalGuion').style.display = "block";
}

function closeGuion() {
    document.getElementById('ModalGuion').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModal')) {
        closeGuion();
    }
}

/* REALIZA LA FUNCION DEL MODAL PAGOS */

function openTipiPagos() {
    document.getElementById('myModalPagos').style.display = "block";
}

function closeTipiPagos() {
    document.getElementById('myModalPagos').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalPagos')) {
        closeTipiPagos();
    }
}

function openGuionPagos() {
    document.getElementById('ModalGuionPagos').style.display = "block";
}

function closeGuionPagos() {
    document.getElementById('ModalGuionPagos').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalPagos')) {
        closeGuionPagos();
    }
}
/* REALIZA LA FUNCION DEL MODAL ORDENES  */

function openTipiOrden() {
    document.getElementById('myModalOrden').style.display = "block";
}

function closeTipiOrden() {
    document.getElementById('myModalOrden').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalOrden')) {
        closeTipiOrden();
    }
}

function openGuionOrden() {
    document.getElementById('ModalGuionOrden').style.display = "block";
}

function closeGuionOrden() {
    document.getElementById('ModalGuionOrden').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalOrden')) {
        closeGuionOrden();
    }
}


/* REALIZA LA FUNCION DEL MODAL VELOCIDAD CONTRATADA */

function openTipiVel() {
    document.getElementById('myModalVel').style.display = "block";
}

function closeTipiVel() {
    document.getElementById('myModalVel').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalVel')) {
        closeTipiVel();
    }
}

function openGuionVel() {
    document.getElementById('ModalGuionVel').style.display = "block";
}

function closeGuionVel() {
    document.getElementById('ModalGuionVel').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalVel')) {
        closeGuionVel();
    }
}
/* REALIZA LA FUNCION DEL MODAL FALLA VOZ Y DATOS  */

function openTipiSenal() {
    document.getElementById('myModalSenal').style.display = "block";
}

function closeTipiSenal() {
    document.getElementById('myModalSenal').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalSenal')) {
        closeTipiSenal();
    }
}

function openGuionSenal() {
    document.getElementById('ModalGuionSenal').style.display = "block";
}

function closeGuionSenal() {
    document.getElementById('ModalGuionSenal').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalSenal')) {
        closeGuionSenal();
    }
}

/* REALIZA LA FUNCION DEL MODAL FALLA  GENERAL  */

function openTipiFalla() {
    document.getElementById('myModalFalla').style.display = "block";
}

function closeTipiFalla() {
    document.getElementById('myModalFalla').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalFalla')) {
        closeTipiFalla();
    }
}

function openGuionFalla() {
    document.getElementById('ModalGuionFalla').style.display = "block";
}

function closeGuionFalla() {
    document.getElementById('ModalGuionFalla').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalFalla')) {
        closeGuionFalla();
    }
}


/* REALIZA LA FUNCION DEL MODAL QUEJAS */

function openTipiQuejas() {
    document.getElementById('myModalQuejas').style.display = "block";
}

function closeTipiQuejas() {
    document.getElementById('myModalQuejas').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalQuejas')) {
        closeTipiQuejas();
    }
}

function openGuionQuejas() {
    document.getElementById('ModalGuionQuejas').style.display = "block";
}

function closeGuionQuejas() {
    document.getElementById('ModalGuionQuejas').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalQuejas')) {
        closeGuionQuejas();
    }
}

/* REALIZA LA FUNCION DEL MODAL PUERTOS EN UMP */

function openTipiPuertos() {
    document.getElementById('myModalPuertos').style.display = "block";
}

function closeTipiPuertos() {
    document.getElementById('myModalPuertos').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalPuertos')) {
        closeTipiPuertos();
    }
}

function openGuionPuertos() {
    document.getElementById('ModalGuionPuerto').style.display = "block";
}

function closeGuionPuertos() {
    document.getElementById('ModalGuionPuertos').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalPuertos')) {
        closeGuionPuertos();
    }
}


/* REALIZA LA FUNCION DEL MODAL NIVELES OK */

function openTipiNivel() {
    document.getElementById('myModalNivel').style.display = "block";
}

function closeTipiNivel() {
    document.getElementById('myModalNivel').style.display = "none";
}

window.onclick = function (event) {
    if (event.target == document.getElementById('myModalNivel')) {
        closeTipiNivel();
    }
}

function openGuionNivel() {
    document.getElementById('ModalGuionNivel').style.display = "block";
}

function closeGuionNivel() {
    document.getElementById('ModalGuionNivel').style.display = "none";
}


window.onclick = function (event) {
    if (event.target == document.getElementById('myModalNivel')) {
        closeGuionNivel();
    }
}













